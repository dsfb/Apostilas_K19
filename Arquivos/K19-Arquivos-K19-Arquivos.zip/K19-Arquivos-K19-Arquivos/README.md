Arquivos utilizados nos exercícios das apostilas da K19.
